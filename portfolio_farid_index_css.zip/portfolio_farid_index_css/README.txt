PORTFOLIO FARID — 2 FILES

File: index.html
- Semua struktur dan isi website (header, hero, tentang, pendidikan, skill, proyek, kontak, footer) ada di sini.

File: style.css
- Semua tampilan website, termasuk warna, ukuran, jarak, dan layout, ada di sini.
- Untuk mengganti warna, cari bagian :root di awal file lalu ubah nilai variabel seperti --background, --surface, --text, --muted, --border, dan --black.

PENTING
- Simpan index.html dan style.css dalam folder yang sama.
- Buka index.html di browser.
- Jika menggunakan VS Code, bisa jalankan dengan Live Server.
- Pastikan path foto di index.html sesuai lokasi file foto yang kamu punya.
